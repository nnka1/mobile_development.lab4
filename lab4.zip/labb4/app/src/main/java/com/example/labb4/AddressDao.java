package com.example.labb4;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import io.reactivex.rxjava3.core.Single;
import java.util.List;


@Dao
public interface AddressDao {
    @Insert
    void insert(Address address);

    @Query("SELECT * FROM address_table")
    Single<List<Address>> getAll();

    @Query("SELECT address FROM address_table WHERE address = :address")
    Single<List<String>> getAddressIfExists(String address); //Это важно!  Single<List<String>>

    @Query("DELETE FROM address_table")
    void deleteAll();
}
