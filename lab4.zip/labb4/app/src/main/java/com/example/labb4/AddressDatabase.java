package com.example.labb4;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

@Database(entities = {Address.class}, version = 1, exportSchema = false)
public abstract class AddressDatabase extends RoomDatabase {
    public abstract AddressDao addressDao();

    private static volatile AddressDatabase INSTANCE;

    public static AddressDatabase getDatabase(final Context context) {
        if (INSTANCE == null) {
            synchronized (AddressDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                                    AddressDatabase.class, "address_database")
                            .build();
                }
            }
        }
        return INSTANCE;
    }
}
