package com.example.labb4;
import org.json.JSONObject;
import org.json.JSONException;

public class PostOffice {
    public String value;
    public String unrestricted_value;
    public String postal_code;
    public boolean is_closed;
    public String type_code;
    public String address_str;
    public String address_kladr_id;
    public String address_qc;
    public double geo_lat;
    public double geo_lon;
    public String schedule_mon;
    public String schedule_tue;
    public String schedule_wed;
    public String schedule_thu;
    public String schedule_fri;
    public String schedule_sat;
    public String schedule_sun;

    public PostOffice(JSONObject jsonObject) throws JSONException {
        this.value = jsonObject.getString("value");
        this.unrestricted_value = jsonObject.getString("unrestricted_value");
        JSONObject data = jsonObject.getJSONObject("data");
        this.postal_code = data.optString("postal_code", ""); // optString для обработки возможного отсутствия ключа
        this.is_closed = data.optBoolean("is_closed", false);
        this.type_code = data.optString("type_code", "");
        this.address_str = data.optString("address_str", "");
        this.address_kladr_id = data.optString("address_kladr_id", "");
        this.address_qc = data.optString("address_qc", "");
        this.geo_lat = data.optDouble("geo_lat", 0.0);
        this.geo_lon = data.optDouble("geo_lon", 0.0);
        this.schedule_mon = data.optString("schedule_mon", "");
        this.schedule_tue = data.optString("schedule_tue", "");
        this.schedule_wed = data.optString("schedule_wed", "");
        this.schedule_thu = data.optString("schedule_thu", "");
        this.schedule_fri = data.optString("schedule_fri", "");
        this.schedule_sat = data.optString("schedule_sat", "");
        this.schedule_sun = data.optString("schedule_sun", "");
    }

    @Override
    public String toString() {
        return address_str; // Или любое другое поле для отображения в ListView
    }
}
