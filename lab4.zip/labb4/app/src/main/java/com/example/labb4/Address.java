package com.example.labb4;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "address_table")
public class Address {
    @PrimaryKey(autoGenerate = true)
    public int uid;

    @ColumnInfo(name = "address")
    public String address;

    public Address(String address) {
        this.address = address;
    }

    // Добавляем геттер для поля address
    public String getAddress() {
        return address;
    }
}
