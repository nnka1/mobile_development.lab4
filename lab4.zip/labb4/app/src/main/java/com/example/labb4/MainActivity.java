
package com.example.labb4;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.core.Single;
import io.reactivex.rxjava3.disposables.CompositeDisposable;
import io.reactivex.rxjava3.schedulers.Schedulers;


public class MainActivity extends AppCompatActivity {
    private static final String DADATA_API_KEY = "80585eb6b2f97bc9864469c3b612e06532e68c67"; // Замените на ваш API-ключ
    private static final String DADATA_URL = "https://suggestions.dadata.ru/suggestions/api/4_1/rs/suggest/postal_unit";
    private EditText addressEditText;
    private ListView postOfficesListView;
    private RequestQueue requestQueue;
    private Button searchButton;
    private AddressDatabase addressDatabase;
    private PostOfficeAdapter adapter;
    private List<String> currentAddresses = new ArrayList<>();
    private CompositeDisposable disposables = new CompositeDisposable();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        requestQueue = Volley.newRequestQueue(this);
        addressEditText = findViewById(R.id.addressEditText);
        searchButton = findViewById(R.id.searchButton);
        postOfficesListView = findViewById(R.id.postOfficesListView);
        Button savedAddressesButton = findViewById(R.id.savedAddressesButton);
        Button clearButton = findViewById(R.id.clearButton); // Get the clear button

        addressDatabase = AddressDatabase.getDatabase(this);
        adapter = new PostOfficeAdapter(this, addressDatabase);
        postOfficesListView.setAdapter(adapter);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        searchButton.setOnClickListener(v -> {
            String address = addressEditText.getText().toString();
            if (address.isEmpty()) {
                Toast.makeText(this, "Пожалуйста, введите адрес", Toast.LENGTH_SHORT).show();
            } else {
                findNearestPostOffice(address);
            }
        });

        savedAddressesButton.setOnClickListener(v -> showSavedAddresses());

        clearButton.setOnClickListener(v -> clearDatabase()); // Add click listener for clear button

    }

    private void findNearestPostOffice(String address) {
        JSONObject jsonBody = new JSONObject();
        try {
            jsonBody.put("query", address);
        } catch (JSONException e) {
            Log.e("DadataError", "Error creating JSON request: ", e);
            showError("Ошибка при формировании запроса.");
            return;
        }

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, DADATA_URL, jsonBody,
                response -> {
                    try {
                        List<String> postOfficeAddresses = new ArrayList<>();
                        JSONArray suggestions = response.getJSONArray("suggestions");
                        if (suggestions.length() == 0) {
                            showError("Почтовые отделения не найдены по указанному адресу.");
                            return;
                        }
                        for (int i = 0; i < suggestions.length(); i++) {
                            JSONObject suggestion = suggestions.getJSONObject(i);
                            if (suggestion.has("data")) {
                                JSONObject data = suggestion.getJSONObject("data");
                                String foundAddress = data.getString("address_str");
                                postOfficeAddresses.add(foundAddress);
                            } else {
                                Log.w("DadataWarning", "Suggestion object missing 'data' field: " + suggestion.toString());
                            }
                        }
                        runOnUiThread(() -> {
                            currentAddresses = postOfficeAddresses;
                            adapter.setSearchResults(currentAddresses);
                        });
                    } catch (JSONException e) {
                        Log.e("DadataError", "Error parsing JSON response: ", e);
                        showError("Ошибка обработки ответа от сервера.");
                    }
                },
                error -> {
                    Log.e("DadataError", "Network or API error: ", error);
                    if (error.networkResponse != null) {
                        Log.e("DadataError", "Error code: " + error.networkResponse.statusCode);
                    }
                    showError("Ошибка сети или API. Проверьте подключение к интернету.");
                }) {
            @Override
            public Map<String, String> getHeaders() {
                HashMap<String, String> headers = new HashMap<>();
                headers.put("Authorization", "Token " + DADATA_API_KEY);
                headers.put("Content-Type", "application/json");
                headers.put("Accept", "application/json");
                return headers;
            }
        };
        requestQueue.add(jsonObjectRequest);
    }


    private void showError(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    private void showSavedAddresses() {
        disposables.add(addressDatabase.addressDao().getAll()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(addresses -> {
                    currentAddresses = addresses.stream().map(Address::getAddress).collect(Collectors.toList());
                    adapter.setSavedAddresses(currentAddresses);
                }, error -> {
                    Log.e("DBError", "Error getting saved addresses", error);
                    showError("Ошибка загрузки сохраненных адресов!");
                }));
    }

    public void saveAddress(String address) {
        disposables.add(addressDatabase.addressDao().getAddressIfExists(address)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .flatMap(existingAddresses -> {
                    if (existingAddresses == null || existingAddresses.isEmpty()) {
                        return Single.fromCallable(() -> {
                            addressDatabase.addressDao().insert(new Address(address));
                            return "Адрес сохранен!";
                        }).subscribeOn(Schedulers.io());
                    } else {
                        return Single.just("Такой адрес уже есть!");
                    }
                })
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(result -> {
                    Toast.makeText(this, result, Toast.LENGTH_SHORT).show();
                    showSavedAddresses();
                }, error -> {
                    Log.e("DBError", "Error saving or checking address", error);
                    showError("Ошибка сохранения или проверки адреса!");
                }));
    }

    private void clearDatabase() {
        disposables.add(Single.fromCallable(() -> {
                    addressDatabase.addressDao().deleteAll();
                    return "База данных очищена!";
                }).subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(result -> {
                    Toast.makeText(this, result, Toast.LENGTH_SHORT).show();
                    adapter.setSavedAddresses(new ArrayList<>()); // Обновляем адаптер после очистки
                }, error -> {
                    Log.e("DBError", "Error clearing database", error);
                    showError("Ошибка очистки базы данных!");
                }));
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        disposables.dispose();
    }
}
