package com.example.labb4;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.util.Log;
import java.util.List;
import java.util.ArrayList;
import java.util.stream.Collectors;

public class PostOfficeAdapter extends BaseAdapter {

    private Context context;
    private List<String> searchResults;
    private List<String> savedAddresses;
    private AddressDatabase addressDatabase;

    public PostOfficeAdapter(Context context, AddressDatabase addressDatabase) {
        this.context = context;
        this.searchResults = new ArrayList<>();
        this.savedAddresses = new ArrayList<>();
        this.addressDatabase = addressDatabase;
    }

    public void setSearchResults(List<String> newSearchResults) {
        this.searchResults = newSearchResults;
        this.savedAddresses = new ArrayList<>(); // Очищаем сохраненные адреса при поиске
        notifyDataSetChanged();
    }

    public void setSavedAddresses(List<String> newSavedAddresses) {
        this.savedAddresses = newSavedAddresses;
        this.searchResults = new ArrayList<>(); // Очищаем результаты поиска при отображении сохраненных
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        return searchResults.size() > 0 ? searchResults.size() : savedAddresses.size();
    }

    @Override
    public Object getItem(int position) {
        if (searchResults.size() > 0) {
            return searchResults.get(position);
        } else if (savedAddresses.size() > 0) {
            return savedAddresses.get(position);
        }
        return null;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.item_post_office, parent, false);
        }

        TextView addressTextView = convertView.findViewById(R.id.postOfficeAddressTextView);
        Button saveButton = convertView.findViewById(R.id.saveButton);

        String address;
        boolean isSearchResult = searchResults.size() > 0 && position < searchResults.size();

        if (isSearchResult) {
            address = searchResults.get(position);
            saveButton.setVisibility(View.VISIBLE);
        } else {
            address = savedAddresses.get(position);
            saveButton.setVisibility(View.GONE);
        }

        addressTextView.setText(address);

        saveButton.setOnClickListener(v -> {
            String addressToSave = searchResults.size() > 0 ? searchResults.get(position) : savedAddresses.get(position);
            ((MainActivity) context).saveAddress(addressToSave);
        });

        return convertView;
    }

}
